""" configuration file """

LOCALHOST = "localhost"
LOCAL_DB_USERNAME = "root"
LOCAL_DB_PW = "TowerOrange@21D"
LOCAL_DB_NAME = "shapementor_data"

# real google cloud db server host info
DB_HOST = "aiadvisor.cuorsbapmndf.us-east-2.rds.amazonaws.com"
DB_USERNAME = "admin"
DB_PW = "shapementor"
DB_NAME = "aiadvisor"
